import VoiceBot from "./VoiceBot";

function App() {
  return <VoiceBot />;
}

export default App;
